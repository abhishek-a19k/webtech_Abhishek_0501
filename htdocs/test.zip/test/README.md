

The application was initially created by using [php](http:php.net), [mysql](https://www.mysql.com) and [bootstrap](http://getbootstrap.com). 

I have done this application as my mini project for 5th semester in Deerwalk Institute of Technology and this project was then purchased by Deerwalk Sifal School.


