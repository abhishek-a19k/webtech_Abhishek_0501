

<ul>
  <li>
    <a href="user_function.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="user_history.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
       <span>History</span>
      </a>

  </li>

   <li>

       <a href="notify.php" >
            <i class="glyphicon glyphicon-bell"></i>
            <span>Notify</span>
        </a>
    </li>

</ul>
